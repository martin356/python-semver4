# Overview
A python module to deal with modified semantic versioning.